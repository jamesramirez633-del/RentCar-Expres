namespace RentCar_Express;
partial class Form1
{
    private System.ComponentModel.IContainer? components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        txtCliente = new TextBox(); chkCorporativo = new CheckBox();
        dtpSalida = new DateTimePicker(); txtVehiculo = new TextBox();
        txtTarifa = new TextBox(); nudDias = new NumericUpDown();
        grpSeguro = new GroupBox(); rbtBasico = new RadioButton();
        rbtCompleto = new RadioButton(); chkGps = new CheckBox();
        grpEntrega = new GroupBox(); rbtSucursal = new RadioButton();
        rbtDomicilio = new RadioButton(); lstAlquileres = new ListView();
        btnAgregar = new Button(); btnCalcular = new Button();
        btnLimpiar = new Button(); btnSalir = new Button();
        lblSubtotal = new Label(); lblDescuento = new Label();
        lblDomicilio = new Label(); lblItbis = new Label();
        lblTotal = new Label(); lblEncabezado = new Label();
        SuspendLayout();

        lblEncabezado.Text = "RENTACAR EXPRESS - ALQUILERES";
        lblEncabezado.Font = new Font("Segoe UI", 16, FontStyle.Bold);
        lblEncabezado.AutoSize = true; lblEncabezado.Location = new Point(24, 18);

        AddLabel("Cliente:", 25, 70);
        txtCliente.SetBounds(130, 66, 260, 27);
        chkCorporativo.Text = "Cliente corporativo";
        chkCorporativo.SetBounds(130, 102, 180, 25);

        AddLabel("Fecha de salida:", 25, 140);
        dtpSalida.SetBounds(130, 136, 260, 27);
        dtpSalida.Format = DateTimePickerFormat.Short;

        AddLabel("Vehículo:", 25, 180);
        txtVehiculo.SetBounds(130, 176, 260, 27);
        AddLabel("Tarifa diaria:", 25, 220);
        txtTarifa.SetBounds(130, 216, 150, 27);
        AddLabel("Días:", 25, 260);
        nudDias.SetBounds(130, 256, 100, 27);
        nudDias.Minimum = 1; nudDias.Maximum = 30;

        grpSeguro.Text = "Seguro"; grpSeguro.SetBounds(25, 305, 180, 95);
        rbtBasico.Text = "Básico"; rbtBasico.SetBounds(12, 25, 100, 25);
        rbtCompleto.Text = "Completo (+RD$300)";
        rbtCompleto.SetBounds(12, 55, 160, 25);
        grpSeguro.Controls.AddRange(new Control[] { rbtBasico, rbtCompleto });

        chkGps.Text = "GPS (+RD$100 por día)";
        chkGps.SetBounds(25, 410, 190, 25);

        grpEntrega.Text = "Entrega"; grpEntrega.SetBounds(220, 305, 180, 95);
        rbtSucursal.Text = "En sucursal"; rbtSucursal.SetBounds(12, 25, 120, 25);
        rbtDomicilio.Text = "Domicilio (+RD$500)";
        rbtDomicilio.SetBounds(12, 55, 160, 25);
        grpEntrega.Controls.AddRange(new Control[] { rbtSucursal, rbtDomicilio });

        btnAgregar.Text = "Agregar alquiler"; btnAgregar.SetBounds(440, 65, 190, 38);
        btnAgregar.Click += btnAgregar_Click;
        lstAlquileres.SetBounds(440, 120, 470, 250);

        AddLabel("Subtotal:", 440, 390); lblSubtotal = MakeValueLabel(570, 390);
        AddLabel("Descuento:", 440, 420); lblDescuento = MakeValueLabel(570, 420);
        AddLabel("Domicilio:", 440, 450); lblDomicilio = MakeValueLabel(570, 450);
        AddLabel("ITBIS (18%):", 440, 480); lblItbis = MakeValueLabel(570, 480);
        AddLabel("TOTAL A PAGAR:", 440, 515); lblTotal = MakeValueLabel(570, 515);
        lblTotal.Font = new Font("Segoe UI", 11, FontStyle.Bold);

        btnCalcular.Text = "Calcular total"; btnCalcular.SetBounds(25, 465, 120, 38);
        btnCalcular.Click += btnCalcular_Click;
        btnLimpiar.Text = "Nuevo alquiler"; btnLimpiar.SetBounds(155, 465, 120, 38);
        btnLimpiar.Click += btnLimpiar_Click;
        btnSalir.Text = "Salir"; btnSalir.SetBounds(285, 465, 100, 38);
        btnSalir.Click += btnSalir_Click;

        Controls.AddRange(new Control[] { lblEncabezado, txtCliente, chkCorporativo,
            dtpSalida, txtVehiculo, txtTarifa, nudDias, grpSeguro, chkGps,
            grpEntrega, btnAgregar, lstAlquileres, btnCalcular, btnLimpiar,
            btnSalir, lblSubtotal, lblDescuento, lblDomicilio, lblItbis, lblTotal });
        ClientSize = new Size(940, 570);
        StartPosition = FormStartPosition.CenterScreen;
        ResumeLayout(false); PerformLayout();
    }

    private void AddLabel(string text, int x, int y)
    {
        Controls.Add(new Label { AutoSize = true, Text = text, Location = new Point(x, y + 4) });
    }
    private Label MakeValueLabel(int x, int y)
    {
        var label = new Label { AutoSize = true, Text = "RD$ 0.00", Location = new Point(x, y + 4) };
        Controls.Add(label); return label;
    }

    private TextBox txtCliente, txtVehiculo, txtTarifa;
    private CheckBox chkCorporativo, chkGps;
    private DateTimePicker dtpSalida;
    private NumericUpDown nudDias;
    private GroupBox grpSeguro, grpEntrega;
    private RadioButton rbtBasico, rbtCompleto, rbtSucursal, rbtDomicilio;
    private ListView lstAlquileres;
    private Button btnAgregar, btnCalcular, btnLimpiar, btnSalir;
    private Label lblSubtotal, lblDescuento, lblDomicilio, lblItbis, lblTotal, lblEncabezado;
}
