# RentCar Express
Proyecto base de práctica en C# Windows Forms.

**Autor:** Ismael Ramírez

## Requisitos
- Windows
- Visual Studio 2022 con la carga de trabajo Desarrollo de escritorio con .NET
- .NET 8 SDK

## Ejecutar
1. Extrae el ZIP.
2. Abre `RentCar-Express.csproj` en Visual Studio.
3. Presiona F5.

La interfaz se abre y permite explorar los controles. Los eventos de agregar alquiler
y calcular total contienen comentarios para completar la lógica de la práctica.
